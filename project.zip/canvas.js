var canvas = document.querySelector('canvas');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var game_active = false;
var active_player = 1;
var c = canvas.getContext('2d');
var gameboard = [];


var DrawPiece = function(A1,A2,A3){
	var X = 300;
	var Y = 100;
	var S = 80;
	var R = 30;
	var x = S/2;
	var addX = A1*S;
	var addY = A2*S;
	X = X + addX;
	Y = Y + addY;
	
	c.fillStyle = "brown";
	c.fillRect(X,Y,S,S);
	
	c.beginPath();
	c.arc(X+x,Y+x,R,0,Math.PI*2,false);
	c.strokeStyle = "green";
	c.stroke();
	if(A3 == 0){
		c.fillStyle = "grey";
		c.fill();
	}else if(A3 == 1){
		c.fillStyle = "yellow";
		c.fill();
	}else if(A3 ==2){
		c.fillStyle = "red";
		c.fill();
	}	
};

var BeginGame = function(){
	
	if (game_active == true) return false; 
	game_active = true; 
				
	for (row=0; row<6; row++) {
		gameboard[row] = [];
		for (col=0; col<7; col++) {
			gameboard[row][col] = 0;
		}	
	}		
	BoardUpdate();	
	active_player = 1;

	
};

var BoardUpdate = function(){
	Button();
	Button2();
	for (row = 0; row<6; row++) {
		for (col=0; col<7; col++) {
			DrawPiece(col,row,gameboard[row][col]);	
		}	
	}
};

var Drop = function(A2,P){
	for(i = 5; i >=0;i--){
		if(gameboard[i][A2]==0){
			gameboard[i][A2] = P;
			break;
		}
	}
	BoardUpdate();
};

var Button = function(){
	var X = 300;
	var Y = 10;
	var S = 80;
	
	for(i=0;i<7;i++){
		c.fillStyle = "white";
		c.fillRect(X+(i*S),Y,S-10,S);
		c.font = "30px Arial";
		c.fillStyle = "green";
		c.fillText("Drop",X+(i*S)+2,50);

	}

};

var Button2 = function(){
	var X = 100;
	var Y = 10;
	var S = 80;
	
	c.fillStyle = "Blue";
	c.fillRect(X,Y,S*2,S);
	c.font = "30px Arial";
	c.fillStyle = "Black";
	c.fillText("Begin game",X,50);
	
	c.fillStyle = "Blue";
	c.fillRect(X,Y+100,S*2,S);
	c.font = "30px Arial";
	c.fillStyle = "Black";
	c.fillText("Turn info",X+15,160);

};

var mouse = {
	x:undefined,
	y:undefined
}


var ButtonPush = function ButtonPush(){
	
	window.addEventListener('click', 
	function(onclick){
		mouse.x = event.x;
		mouse.y = event.y;
		console.log(event);
		if (mouse.y>10 && mouse.y<90){
			if (mouse.x >100 && mouse.x<260){
				location.reload();
			}
		}
		
		if (mouse.y>110 && mouse.y<190){
			if (mouse.x >100 && mouse.x<260){
				alert("The player turn is = Player" + active_player);
			}
		}
		if (mouse.y>10 && mouse.y<90){
			if (mouse.x >300 && mouse.x<370){
				Drop(0,active_player);
			}else if(mouse.x >380 && mouse.x<450){
				Drop(1,active_player);
				
			}else if(mouse.x >460 && mouse.x<530){
				Drop(2,active_player);
				
			}else if(mouse.x >540 && mouse.x<610){
				Drop(3,active_player);
				
			}else if(mouse.x >620 && mouse.x<690){
				Drop(4,active_player);
			
			}else if(mouse.x >700 && mouse.x<770){
				Drop(5,active_player);
	
			}else if(mouse.x >780 && mouse.x<850){
				Drop(6,active_player);
			}
		}
		
		if (WinnerChecker() != null){
			alert("The winner is player " + active_player+
			"\n please press the begin button to play again.");
		}
		if(active_player == 1){
					active_player = 2;
				}else if(active_player == 2){
					active_player = 1;
				}

	mouse.x = null;
	mouse.y = null;
	},false)
	
};	


var WinnerChecker = function(){
			
	for (i=1; i<=2; i++) {
		for (col = 0; col <=3; col++) {
			for (row = 0; row <=5; row++) {
				if (gameboard[row][col] == i) {
					if ((gameboard[row][col+1] == i) && (gameboard[row][col+2] == i) && (gameboard[row][col+3] == i)) {
						return i;
					}
				}
			}
		}
	}
				
	//check top-to-bottom
	for (i=1; i<=2; i++) {
		for (col = 0; col <=6; col++) {
			for (row = 0; row <=2; row++) {
				if (gameboard[row][col] == i) {
					if ((gameboard[row+1][col] == i) && (gameboard[row+2][col] == i) && (gameboard[row+3][col] == i)) {
						return i;
					}
				}
			}
		}
	}
				
	//check diagnol down
	for (i=1; i<=2; i++) {
		for (col = 0; col <=3; col++) {
			for (row = 0; row <=2; row++) {
				if (gameboard[row][col] == i) {
					if ((gameboard[row+1][col+1] == i) && (gameboard[row+2][col+2] == i) && (gameboard[row+3][col+3] == i)) {
						return i;
					}
				}
			}
		}
	}
								
	//check diagnol up
	for (i=1; i<=2; i++) {
		for (col = 0; col <=3; col++) {
			for (row = 3; row <=5; row++) {
				if (gameboard[row][col] == i) {
					if ((gameboard[row-1][col+1] == i) && (gameboard[row-2][col+2] == i) && (gameboard[row-3][col+3] == i)) {
						return i;
					}
				}
			}
		}
	}
}
			
var Test = function(){
	BeginGame();
	if(active_player == 1){
		ButtonPush(1);
	}else if(active_player == 2){
		ButtonPush(2);
	}
	

};

BeginGame();
ButtonPush();